package com.plastinka.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

public class PlayerWidget extends AppWidgetProvider {
    @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { push(c, m, ids); }

    static void refresh(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, PlayerWidget.class));
        if (ids != null && ids.length > 0) push(c, m, ids);
    }

    static PendingIntent pi(Context c, String cmd, int code) {
        boolean alive = MainActivity.inst != null;
        Intent i = new Intent(c, alive ? WidgetCmd.class : MainActivity.class).putExtra("c", cmd);
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        return alive ? PendingIntent.getBroadcast(c, code, i, fl) : PendingIntent.getActivity(c, code, i, fl);
    }

    static void push(Context c, AppWidgetManager m, int[] ids) {
        SharedPreferences p = c.getSharedPreferences("p", 0);
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget_player);
        v.setTextViewText(R.id.wt, p.getString("t", "Пластинка"));
        v.setTextViewText(R.id.wa, p.getString("a", "Нажми, чтобы открыть"));
        v.setImageViewResource(R.id.wp, p.getBoolean("pl", false) ? R.drawable.ic_pause : R.drawable.ic_play);
        v.setOnClickPendingIntent(R.id.wpv, pi(c, "prev", 1));
        v.setOnClickPendingIntent(R.id.wp, pi(c, "toggle", 2));
        v.setOnClickPendingIntent(R.id.wn, pi(c, "next", 3));
        v.setOnClickPendingIntent(R.id.ww, pi(c, "wave", 4));
        v.setOnClickPendingIntent(R.id.wt, PendingIntent.getActivity(c, 5, new Intent(c, MainActivity.class),
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        m.updateAppWidget(ids, v);
    }
}
