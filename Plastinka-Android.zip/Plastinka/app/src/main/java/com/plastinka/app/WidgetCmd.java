package com.plastinka.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class WidgetCmd extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        String cmd = i.getStringExtra("c");
        if (cmd == null) return;
        MainActivity a = MainActivity.inst;
        if ("close".equals(cmd)) {
            if (a != null) a.run("window.cmd&&window.cmd('pause')");
            c.stopService(new Intent(c, PlayerService.class));
            c.getSharedPreferences("p", 0).edit().putBoolean("pl", false).apply();
            PlayerWidget.refresh(c);
            return;
        }
        if (a != null) {
            a.run("window.cmd&&window.cmd('" + cmd + "')");
        } else {
            try {
                c.startActivity(new Intent(c, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("c", cmd));
            } catch (Exception e) { }
        }
    }
}
