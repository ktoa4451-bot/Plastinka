package com.plastinka.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.IBinder;

public class PlayerService extends Service {
    static PlayerService inst;
    static final String CH = "player";

    @Override public void onCreate() {
        super.onCreate();
        inst = this;
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager.class).createNotificationChannel(
                new NotificationChannel(CH, "Плеер", NotificationManager.IMPORTANCE_LOW));
        }
    }

    @Override public int onStartCommand(Intent i, int f, int s) {
        Notification n = build(this);
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(1, n);
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() { inst = null; super.onDestroy(); }
    @Override public IBinder onBind(Intent i) { return null; }

    static void refresh(Context c) {
        if (inst != null) c.getSystemService(NotificationManager.class).notify(1, build(c));
    }

    static Notification build(Context c) {
        SharedPreferences p = c.getSharedPreferences("p", 0);
        boolean pl = p.getBoolean("pl", false);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CH) : new Notification.Builder(c);
        b.setSmallIcon(R.drawable.ic_wave)
            .setContentTitle(p.getString("t", "Пластинка"))
            .setContentText(p.getString("a", ""))
            .setOngoing(true).setOnlyAlertOnce(true)
            .setContentIntent(PendingIntent.getActivity(c, 9, new Intent(c, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        b.addAction(act(c, R.drawable.ic_prev, "Назад", "prev", 11));
        b.addAction(act(c, pl ? R.drawable.ic_pause : R.drawable.ic_play, pl ? "Пауза" : "Играть", "toggle", 12));
        b.addAction(act(c, R.drawable.ic_next, "Вперёд", "next", 13));
        b.addAction(act(c, R.drawable.ic_close, "Закрыть", "close", 14));
        b.setStyle(new Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2));
        return b.build();
    }

    static Notification.Action act(Context c, int icon, String t, String cmd, int code) {
        Intent i = new Intent(c, WidgetCmd.class).putExtra("c", cmd);
        PendingIntent pi = PendingIntent.getBroadcast(c, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Action.Builder(Icon.createWithResource(c, icon), t, pi).build();
    }
}
