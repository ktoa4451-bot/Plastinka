package com.plastinka.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    static MainActivity inst;
    WebView wv;
    ValueCallback<Uri[]> fileCb;
    boolean ready = false;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        inst = this;
        getWindow().setStatusBarColor(0xFF15101F);
        getWindow().setNavigationBarColor(0xFF15101F);
        wv = new WebView(this);
        setContentView(wv);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        wv.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String h = r.getUrl().getHost();
                if (h != null && !h.equals("appassets.androidplatform.net")) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); } catch (Exception e) { }
                    return true;
                }
                return false;
            }
            @Override public void onPageFinished(WebView v, String u) { ready = true; }
        });
        wv.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try { startActivityForResult(p.createIntent(), 1); }
                catch (Exception e) { fileCb = null; return false; }
                return true;
            }
        });
        wv.addJavascriptInterface(new Bridge(), "Android");
        wv.loadUrl("https://appassets.androidplatform.net/assets/index.html");
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2);
        handle(getIntent());
    }

    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); setIntent(i); handle(i); }

    void handle(Intent i) {
        final String c = i == null ? null : i.getStringExtra("c");
        if (c == null) return;
        i.removeExtra("c");
        new Handler(Looper.getMainLooper()).postDelayed(
            () -> run("window.cmd&&window.cmd('" + c + "')"), ready ? 100 : 2000);
    }

    void run(final String js) { runOnUiThread(() -> wv.evaluateJavascript(js, null)); }

    @Override protected void onActivityResult(int rq, int rs, Intent d) {
        if (rq == 1 && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(rs, d));
            fileCb = null;
        } else super.onActivityResult(rq, rs, d);
    }

    @Override public void onBackPressed() { moveTaskToBack(true); }

    @Override protected void onDestroy() {
        if (inst == this) inst = null;
        PlayerWidget.refresh(getApplicationContext());
        super.onDestroy();
    }

    class Bridge {
        @JavascriptInterface public void state(String t, String a, boolean pl) {
            getSharedPreferences("p", 0).edit().putString("t", t).putString("a", a).putBoolean("pl", pl).apply();
            if (pl && PlayerService.inst == null) {
                try {
                    Intent si = new Intent(MainActivity.this, PlayerService.class);
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(si); else startService(si);
                } catch (Exception e) { }
            }
            PlayerService.refresh(MainActivity.this);
            PlayerWidget.refresh(MainActivity.this);
        }
    }
}
